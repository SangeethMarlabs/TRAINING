﻿using Marlabs_UnitOfWork.DTOs;
using Marlabs_UnitOfWork.Models;
using Marlabs_UnitOfWork.UOW;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Marlabs_UnitOfWork.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserProductController : ControllerBase
    {
        private IUnitOfWorkUOW _unitOfWork;
        public UserProductController(IUnitOfWorkUOW unitOfWork)
        {
            this._unitOfWork = unitOfWork;
        }

        [HttpPost("CreateUserProduct")]
        public int Create(UserProductDTO up)
        {
            User objUser = new User
            {
                UserName = up.UserName,
                UserEmail = up.UserEmail,
                UserContactNo = up.UserContactNo,
                UserAddress = up.UserAddress
            };
            Product objProduct = new Product
            {
                ProductName = up.ProductName,
                ProductCategory = up.ProductCategory,
                ProductDesc = up.ProductDesc,
                ProductPrice = up.ProductPrice,
                user = objUser
            };
            _unitOfWork.User.AddUser(objUser);
            _unitOfWork.Product.AddProduct(objProduct);
            _unitOfWork.Complete();
            _unitOfWork.Dispose();
            return 1;
        }

        //[HttpGet("GetUserProduct")]
        //public List<UserDTO> GetUserProduc()
        //{
        //    List<User> lstUser = new List<User>();
        //    _unitOfWork.User.GetUsers().ToList().ForEach(Usr =>
        //    {
        //        User user = null;
        //        Product product = _unitOfWork.Product.GetProduct(Usr.UserId); 
        //        user = new User()
        //        {
        //            UserId = Usr.UserId,
        //            UserAddress = Usr.UserAddress,
        //            Product product = new Product
        //            {
        //                Id = employeeProfessional.Id,
        //                EmpCompany = employeeProfessional.EmpCompany,
        //                EmpDesignation = employeeProfessional.EmpDesignation,
        //                EmpExperience = employeeProfessional.EmpExperience,
        //                EmpSalary = employeeProfessional.EmpSalary,
        //                Employee = employee,
        //                ModifiedDate = DateTime.UtcNow,
        //                IPAddress = Request.HttpContext.Connection.RemoteIpAddress.ToString()
        //            }
        //        };
        //        lstEmployee.Add(employee);
        //    });
        //    return Ok(lstEmployee);
        //}

    }
}
