﻿namespace Marlabs_UnitOfWork.Models
{
    public class User
    {
        public int UserId { get; set; }
        public string UserName { get; set; }
        public string UserEmail { get; set; }
        public string UserContactNo { get; set; }
        public string UserAddress { get; set; }
        Product Product { get; set; }
    }
}
