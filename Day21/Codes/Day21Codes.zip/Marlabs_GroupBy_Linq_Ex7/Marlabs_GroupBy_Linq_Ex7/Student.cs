﻿namespace Marlabs_GroupBy_Linq_Ex7
{
    public class Student
    {
        public int StudentId { get; set; }
        public string StudentName { get; set; }
        public string StudentAddress { get; set; }
        public int StudentAge { get; set; }
    }
}
