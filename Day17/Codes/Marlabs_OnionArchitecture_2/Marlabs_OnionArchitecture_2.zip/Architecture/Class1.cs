﻿using System;

namespace Architecture
{
    public class Class1
    {
    }
}
