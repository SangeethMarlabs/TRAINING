﻿using System;

namespace Infrastructure
{
    public class Class1
    {
    }
}
