﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Marlabs_Structure_Ex2
{
    class Employee
    {
        struct structEmployee
        {
            public int empId;
            public string empName;
            public string empGender;
            public int empSalary;
        }
    }
}
