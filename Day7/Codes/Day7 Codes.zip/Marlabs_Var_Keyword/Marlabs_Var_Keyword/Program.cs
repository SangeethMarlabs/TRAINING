﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Marlabs_Var_Keyword
{
    class Program
    {
        static void Main(string[] args)
        {
            var i = 90;
            Console.WriteLine(i);

            var str = "Sangeeth";
            str = "Sreeshaila";
            Console.WriteLine(str);

            Console.ReadLine();
        }
    }
}
