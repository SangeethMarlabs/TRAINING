﻿using System;

namespace Marlabs_Action_Ex2
{
    public class ArithemeticFunctions
    {
        public void Add(int a, int b)
        {
            Console.WriteLine($"The Addition would be :: {a + b}");
        }
        public void Sub(int a, int b)
        {
            Console.WriteLine($"The Subtraction would be :: {a - b}");
        }
        public void Mul(int a, int b)
        {
            Console.WriteLine($"The Multiplication would be :: {a * b}");
        }
        public void Div(int a, int b)
        {
            Console.WriteLine($"The Division would be :: {a / b}");
        }
    }
}
